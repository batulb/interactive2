$(document).ready(function(){

	$('#button-1').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-2').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-3').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-4').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-5').click(function() {
		alert ("Did you figure out the puzzle yet?");
	});

	$('#button-6').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-7').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-8').click(function() {
		$(this).toggleClass('transform');
	});

	$('#button-9').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-11').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-10').click(function() {
		$(this).toggleClass('transform');
	});

	$('#button-12').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-13').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-14').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-15').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-16').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-17').click(function() {
		$(this).toggleClass('background-color');
	});


	$('#button-19').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-20').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-21').click(function() {
		$(this).toggleClass('shadow');
	});

	// $('#button-21').click(function() {
	// 	$(this).animate({
	// 		opacity: 100,
	// 		marginLeft: '280px',
	// 		fontSize: '24px',
	// 		borderWidth: '10px'
	// 	}, 200 );
	// });

	$('#button-22').click(function() {
		$('#button-21').toggleClass('background-color');
	});

	$('#button-23').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-24').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-25').click(function() {
		$(this).toggleClass('background-color');
	});

	$('#button-26').click(function() {
		$(this).toggleClass('transform');
	});


	// $('#button-5').click(function() {
	// 	$(this).next('.item').toggleClass('circle');
	// });



});
